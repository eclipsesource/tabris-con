var FreeBlockInsertor = require("../src/data/FreeBlockInsertor");

var chai = require("chai");
var expect = chai.expect;

describe("FreeBlockInsertor", function() {
  var freeBlockInsertor;

  beforeEach(function() {
    freeBlockInsertor = new FreeBlockInsertor({CONFERENCE_TIMEZONE: "Europe/Berlin", CONFERENCE_SCHEDULE_HOUR_RANGE: [12, 16]});
  });

  it("doesn't fail with empty array", function() {
    freeBlockInsertor.insert([]);
  });

  it("doesn't modify array of one element", function() {
    var array = [{
      startTimestamp: "2015-11-04T16:35:00.000Z",
      endTimestamp: "2015-11-04T16:35:00.000Z"
    }];

    var newArray = freeBlockInsertor.insert(array);

    expect(newArray).to.deep.equal(array);
  });

  it("inserts round hours in array of two elements", function() {
    var array = [{
      startTimestamp: "2015-11-04T12:35:00.000Z",
      endTimestamp: "2015-11-04T13:35:00.000Z"
    }, {
      startTimestamp: "2015-11-04T14:35:00.000Z",
      endTimestamp: "2015-11-04T15:35:00.000Z"
    }];

    var newArray = freeBlockInsertor.insert(array);

    expect(newArray).to.deep.equal([{
      startTimestamp: "2015-11-04T12:35:00.000Z",
      endTimestamp: "2015-11-04T13:35:00.000Z"
    }, {
      title: "BROWSE SESSIONS",
      variation: "free",
      startTimestamp: "2015-11-04T14:00:00.000Z"
    }, {
      startTimestamp: "2015-11-04T14:35:00.000Z",
      endTimestamp: "2015-11-04T15:35:00.000Z"
    }]);
  });

  it("inserts round hours in array of more than two elements", function() {
    var array = [{
      startTimestamp: "2015-11-04T11:35:00.000Z",
      endTimestamp: "2015-11-04T12:35:00.000Z"
    }, {
      startTimestamp: "2015-11-04T13:35:00.000Z",
      endTimestamp: "2015-11-04T14:35:00.000Z"
    }, {
      startTimestamp: "2015-11-04T15:35:00.000Z",
      endTimestamp: "2015-11-04T16:35:00.000Z"
    }];

    var newArray = freeBlockInsertor.insert(array);

    expect(newArray).to.deep.equal([{
      startTimestamp: "2015-11-04T11:35:00.000Z",
      endTimestamp: "2015-11-04T12:35:00.000Z"
    }, {
      title: "BROWSE SESSIONS",
      variation: "free",
      startTimestamp: "2015-11-04T13:00:00.000Z"
    }, {
      startTimestamp: "2015-11-04T13:35:00.000Z",
      endTimestamp: "2015-11-04T14:35:00.000Z"
    }, {
      title: "BROWSE SESSIONS",
      variation: "free",
      startTimestamp: "2015-11-04T15:00:00.000Z"
    }, {
      startTimestamp: "2015-11-04T15:35:00.000Z",
      endTimestamp: "2015-11-04T16:35:00.000Z"
    }]);
  });
});
