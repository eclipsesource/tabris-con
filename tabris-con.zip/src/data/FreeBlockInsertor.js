var momentTimezone = require("moment-timezone");
var _ = require("lodash");

module.exports = function(appConfig) {

  this.insert = function(blocks) {
    var blocks = _.sortBy(blocks, "startTimestamp");
    var newBlocks = [];

    for (var i = 0; i < blocks.length; i++) {
      var block = blocks[i];
      var nextBlock = blocks[i + 1];
      newBlocks.push(block);

      var blockTime = moment(block.endTimestamp);

      var rangeStart = appConfig.CONFERENCE_SCHEDULE_HOUR_RANGE[0] + 1;
      var rangeEnd = appConfig.CONFERENCE_SCHEDULE_HOUR_RANGE[1] + 1;
      console.log("range start. " + rangeStart);
      console.log("range end. " + rangeEnd);

      _(rangeStart).range(rangeEnd)
        .each(function(roundHour) {
          var roundTime = moment(blockTime)
            .set("hour", roundHour)
            .set("minute", 0)
            .set("millisecond", 0);

          if (i < blocks.length - 1) { // there is no "nextBlock"
            var nextBlockTime = moment(nextBlock.startTimestamp);
            if (
                (blockTime.date() === nextBlockTime.date() &&
                  roundTime >= blockTime && roundTime < roundH(nextBlockTime)) ||

                // different dates -> end of day
                ((blockTime.date() !== nextBlockTime.date()) &&
                  roundTime >= blockTime && roundTime.hour() <= rangeEnd)
                ) {
              newBlocks.push({
                title: "BROWSE SESSIONS",
                variation: "free",
                startTimestamp: roundTime.toJSON()
              });
            }
          } else if (roundTime >= blockTime && roundTime.hour() <= rangeEnd) { // last iteration
            newBlocks.push({
              title: "BROWSE SESSIONS",
              variation: "free",
              startTimestamp: roundTime.toJSON()
            });
          }
        });
    }
    return newBlocks;
  };

  function roundH(time) {
    var rounded = moment(time)
    .set("hour", Math.round(time.hour() + time.minute() / 60))
    .set("minute", 0)
    .set("millisecond", 0);
    return rounded;
  }

  function moment(time) {
    return momentTimezone(time).tz(appConfig.CONFERENCE_TIMEZONE);
  }
};
