# tabris-con
[![Build Status](https://travis-ci.com/eclipsesource/tabris-con.svg?token=crZanj9mR3MBycopDKFp&branch=master)](https://travis-ci.com/eclipsesource/tabris-con)

An exemplary conference app built with Tabris.js.
