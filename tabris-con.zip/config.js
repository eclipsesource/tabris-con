module.exports = {
  DATA_FORMAT: "cod",
  SESSIONS_HAVE_IMAGES: true,
  CONFERENCE_TIMEZONE: "Europe/Berlin",
  CONFERENCE_SCHEDULE_HOUR_RANGE: [7, 17],
  SCHEDULE_PATTERN_ICON_MAP: {
    googleIO: {
      "^After": "schedule_icon_fun",
      "^Badge": "schedule_icon_badge",
      "^Pre-Keynote": "schedule_icon_session",
      "^(Lunch|Breakfast)": "schedule_icon_food",
      ".*": "schedule_icon_session"
    },
    cod: {
      "^Lunch": "schedule_icon_food",
      ".*(Exhibit|Introduction).*": "schedule_icon_session",
      ".*Break$": "schedule_icon_break",
      "^Club": "schedule_icon_fun",
      ".*Stammtisch.*": "schedule_icon_beer",
      ".*Kahoot.*": "schedule_icon_quiz",
      ".*": "schedule_icon_session"
    }
  }
};
